﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace TestApp_Goods
{
    public class SupplyRow : INotifyPropertyChanged
    {
        private int _supplierId;
        private int _productId;
        private int _quantity;
        private double _price_Of_One_Product;
        private string? _description;

        public int SupplierId { get { return _supplierId; } set { _supplierId = value; OnPropertyChanged("SupplierId"); } }
        public int ProductId { get { return _productId; } set { _productId = value; OnPropertyChanged("ProductId"); } }
        public int Quantity { get { return _quantity; } set { _quantity = value; OnPropertyChanged("Quantity"); } }
        public double Price_Of_One_Product { get { return _price_Of_One_Product; } set { _price_Of_One_Product = value; OnPropertyChanged("Price_Of_One_Product"); } }
        public string? Description { get { return _description; } set { _description = value; OnPropertyChanged("Description"); } }
        public double Weight_Of_One_Product { get; set; }
        public double Weight { get; set; }

        public string SupplierName { get; set; }
        public string ProductName { get; set; }

        public event PropertyChangedEventHandler? PropertyChanged;
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}

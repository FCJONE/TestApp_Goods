﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestApp_Goods
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ProductContext _context = new ProductContext();

        private CollectionViewSource productsViewSource;
        private CollectionViewSource suppliersViewSource;
        private CollectionViewSource suppliesViewSource;
        private CollectionViewSource supplyRowViewSource;
        private CollectionViewSource reportRowViewSource;

        private CollectionViewSource supplierNamesViewSource;
        private CollectionViewSource productNamesViewSource;

        public ObservableCollection<string> SupplierNames { get; set; }
        public ObservableCollection<string> ProductNames { get; set; }

        private List<Supply> Supplies { get; set; }
        private List<Supplier> Suppliers { get; set; }
        private List<Product> Products { get; set; }
        private List<SupplyRow> SupplyRows { get; set; }


        public ObservableCollection<SupplyRow> SupplyRowCollection = new();
        public ObservableCollection<ReportRow> ReportRowCollection = new();



        public MainWindow()
        {
            InitializeComponent();
            BindSources();
        }



        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //_context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();

            _context.Products.Load();
            _context.Supplies.Load();
            _context.Suppliers.Load();

            productsViewSource.Source = _context.Products.Local.ToObservableCollection();
            suppliersViewSource.Source = _context.Suppliers.Local.ToObservableCollection();
            suppliesViewSource.Source = _context.Supplies.Local.ToObservableCollection();

            SupplierNames = new ObservableCollection<string>();
            ProductNames = new ObservableCollection<string>();
            Suppliers = new List<Supplier>();
            Supplies = new List<Supply>();
            Products = new List<Product>();
            SupplyRows = new List<SupplyRow>();

            SupplyRowCollection = new();
            ReportRowCollection = new();

            UpdateLists();

            supplierNamesViewSource.Source = SupplierNames;
            productNamesViewSource.Source = ProductNames;
            supplyRowViewSource.Source = SupplyRowCollection;
            reportRowViewSource.Source = ReportRowCollection;
        }



        private void Window_Closed(object sender, EventArgs e)
        {
            _context.Dispose();
        }



        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ClearDBButton.Content += " ✔ ";

            _context.Database.EnsureDeleted();

            BindSources();
            Window_Loaded(sender, e);
     
        }



        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            
            _context.SaveChanges();

            UpdateLists();
        }



        private void UpdateLists()
        {
            Suppliers.Clear();
            Products.Clear();
            SupplierNames.Clear();
            ProductNames.Clear();

            if (_context.Suppliers.Count() > 0)
            {
                foreach (var supplier in _context.Suppliers)
                {
                    Suppliers.Add(supplier);
                    SupplierNames.Add(supplier.Name);
                }

                foreach (var product in _context.Products)
                {
                    Products.Add(product);
                    if (!ProductNames.Contains(product.Name)) ProductNames.Add(product.Name);
                }
            }

            supplyRowDataGrid.Items.Refresh();
            productsDataGrid.Items.Refresh();
            suppliesDataGrid.Items.Refresh();
            suppliersDataGrid.Items.Refresh();
            SupplierComboBox.Items.Refresh();
            ProductComboBox.Items.Refresh();
        }



        private void BindSources()
        {
            productsViewSource = (CollectionViewSource)FindResource(nameof(productsViewSource));
            suppliersViewSource = (CollectionViewSource)FindResource(nameof(suppliersViewSource));
            suppliesViewSource = (CollectionViewSource)FindResource(nameof(suppliesViewSource));
            supplyRowViewSource = (CollectionViewSource)FindResource(nameof(supplyRowViewSource));
            supplierNamesViewSource = (CollectionViewSource)FindResource(nameof(supplierNamesViewSource));
            productNamesViewSource = (CollectionViewSource)FindResource(nameof(productNamesViewSource));
            reportRowViewSource = (CollectionViewSource)FindResource(nameof(reportRowViewSource));
        }

        private void AddSupplyRowButton_Click(object sender, RoutedEventArgs e) //Add supplyrow
        {
            int quantity;
            double price;
            double weight_Of_One_Product;
            int supplierId = SupplierComboBox.SelectedIndex + 1;
            int productId = ProductComboBox.SelectedIndex + 1;
            string description = DescriptionTextBox.Text;
            

            if (int.TryParse(QuantityTextBox.Text, out quantity) && double.TryParse(PriceTextBox.Text.Replace('.', ','), out price)
                && supplierId > 0 && productId > 0 && double.TryParse(WeightTextBox.Text.Replace('.', ','), out weight_Of_One_Product))
            {
                string supplierName = Suppliers.First(sup => sup.SupplierId == supplierId).Name;
                string productName = Products.First(p => p.ProductId == productId).Name;

                SupplyRows.Add(new SupplyRow
                {
                    SupplierId = supplierId,
                    SupplierName = supplierName,
                    ProductId = productId,
                    ProductName = productName,
                    Quantity = quantity,
                    Weight = weight_Of_One_Product * quantity,
                    Weight_Of_One_Product = weight_Of_One_Product,
                    Price_Of_One_Product = price,
                    Description = description
                });

                SupplyRowCollection.Add(SupplyRows.Last());

                QuantityTextBox.Text = "";
                PriceTextBox.Text = "";
                DescriptionTextBox.Text = "";
                WeightTextBox.Text = "";

                SupplierNames.Clear();
                SupplierNames.Add(Suppliers.First(x => x.SupplierId == supplierId).Name);

                SupplierComboBox.SelectedIndex = 0;
                ProductComboBox.SelectedIndex = 0;

            }

        }

        private void Button_Click(object sender, RoutedEventArgs e) //Save Supply
        {
            if (DateTimePickerBox.SelectedDate != null && SupplyRows.Count > 0)
            {
                var _supplierId = 0;
                var _description = string.Empty;
                var products = new List<Product>();

                foreach (var supplyrow in SupplyRows)
                {
                    for (int i = 0; i < supplyrow.Quantity; i++)
                    {
                        var pr = Products.First(x => x.ProductId == supplyrow.ProductId);
                        products.Add(new Product()
                        {
                            Name = pr.Name,
                            Price = supplyrow.Price_Of_One_Product,
                            Weight = supplyrow.Weight_Of_One_Product,
                            Description = pr.Description
                        });
                    }

                    _supplierId = supplyrow.SupplierId;
                    _description = supplyrow.Description;

                }

                DateTime tempDateTime = (DateTime)DateTimePickerBox.SelectedDate;
                tempDateTime = tempDateTime.AddHours(12);

                var newSupply = new Supply
                {
                    Supplier = Suppliers.First(x => x.SupplierId == _supplierId),
                    Products = products,
                    Description = _description,
                    DateTime = tempDateTime
                };

                Supplies.Add(newSupply);
                _context.Supplies.Add(newSupply);

                SupplyRows.Clear();
                SupplyRowCollection.Clear();

                _context.SaveChanges();

                UpdateLists();

                SupplierComboBox.SelectedIndex = 0;
                ProductComboBox.SelectedIndex = 0;
            }

        }



        private void suppliesDataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var supply = suppliesDataGrid.Items.CurrentItem as Supply;
            var str = ""; 
            
            foreach(var item in supply.UniqueProductNames)
            {
                double sumPrice = 0.0;
                double sumWeight = 0.0;

                foreach (var product in supply.Products)
                {
                    if (product.Name == item)
                    {
                        sumPrice += product.Price;
                        sumWeight += product.Weight;
                    }
                }

                str += item + " - " + supply.Products.Count(pr => pr.Name == item) + 
                    " шт. Цена: " + supply.Products.First(pr => pr.Name == item).Price +
                    ". Вес одного: " + supply.Products.First(pr => pr.Name == item).Weight + 
                    "кг. Общий вес: " + sumWeight.ToString("N2") + "кг. Стоимость: " + sumPrice + ". \n";
            }

            MessageBox.Show(str, "Детали поставки");
        }


        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            ReportRowCollection.Clear();

            int choosenSupplierId = SupplierComboBox_ReportsTab.SelectedIndex + 1;
            DateTime dateTimeStart = DateTime.Now;
            DateTime dateTimeEnd = DateTime.Now;

            if (DateTimePickerBox_ReportsTab_Start.SelectedDate != null && DateTimePickerBox_ReportsTab_End.SelectedDate != null)
            {
                dateTimeStart = (DateTime)DateTimePickerBox_ReportsTab_Start.SelectedDate;
                dateTimeEnd = (DateTime)DateTimePickerBox_ReportsTab_End.SelectedDate;
            }
            

            foreach (var supply in _context.Supplies)
            {
                if (supply.Supplier.SupplierId == choosenSupplierId && supply.DateTime > dateTimeStart && supply.DateTime < dateTimeEnd)
                {

                    var _supplyRows = new List<SupplyRow>();

                    foreach (var product in supply.Products)
                    {
                        if (!_supplyRows.Any(row => row.ProductName == product.Name))
                        {
                            _supplyRows.Add(new SupplyRow
                            {
                                ProductId = product.ProductId,
                                ProductName = product.Name,
                                Price_Of_One_Product = product.Price,
                                Weight_Of_One_Product = product.Weight,
                                Quantity = supply.Products.Count(pr => pr.Name == product.Name),
                            });
                        }
                    }

                    foreach (var supplyRow in _supplyRows)
                    {
                        var newReportRow = new ReportRow
                        {
                            SupplyId = supply.SupplyId,
                            ProductId = supplyRow.ProductId,
                            Quantity = supplyRow.Quantity,
                            Weight = supplyRow.Weight_Of_One_Product * supplyRow.Quantity,
                            Price = supplyRow.Price_Of_One_Product * supplyRow.Quantity,
                            Description = supply.Description,
                            Price_Of_One_Product = supplyRow.Price_Of_One_Product,
                            ProductName = supplyRow.ProductName,
                            SupplierName = supply.Supplier.Name,
                            Weight_Of_One_Product = supplyRow.Weight_Of_One_Product,
                            DateTime = supply.DateTime
                        };
                        ReportRowCollection.Add(newReportRow);
                    }


                }
                
            }

            if (ReportRowCollection.Count() > 0)
            ReportRowCollection.Add(new ReportRow
            {
                ProductName = "ИТОГО",
                Weight = ReportRowCollection.Sum(r => r.Weight),
                Price = ReportRowCollection.Sum(r => r.Price),
                Quantity = ReportRowCollection.Sum(r => r.Quantity),
                Description = "ИТОГО"
            });
        }
    }
}

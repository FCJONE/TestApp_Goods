﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp_Goods
{
    public class Supply
    {
        public int SupplyId { get; set; }
        public virtual Supplier Supplier { get; set; }
        public virtual ICollection<Product> Products { get; set; } = new ObservableCollection<Product>();
        public DateTime DateTime { get; set; }
        public int Quantity { get => Products.Count; }
        public double Price { get => Products.Sum(x => x.Price); }
        public double Weight { get => Products.Sum(x => x.Weight); }
        public string? Description { get; set; }

        public List<string> UniqueProductNames 
        { get
            {
                var result = new List<string>();

                foreach (var product in Products)
                {
                    if (!result.Contains(product.Name)) result.Add(product.Name);
                }
                return result;
            }
        }

        public string GetProductNames
        {
            get
            {
                var tempstr = "";
                foreach (var name in UniqueProductNames)
                {
                    tempstr += name + ", ";
                }
                return tempstr.Remove(tempstr.Length - 2);
            }
        }


    }
}
